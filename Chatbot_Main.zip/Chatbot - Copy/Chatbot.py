import spacy
import requests
from bs4 import BeautifulSoup
from flask import Flask, request, jsonify, render_template

# Initialize spaCy NLP model
nlp = spacy.load("en_core_web_md")
print("spaCy model loaded successfully.")

class ChatBot:
    def __init__(self):
        self.content = None  # Placeholder for website content

    def fetch_content(self, url):
        response = requests.get(url)
        if response.status_code == 200:
            soup = BeautifulSoup(response.content, 'html.parser')
            text = soup.get_text()
            self.content = text  # Store the fetched content
        else:
            raise Exception("Failed to fetch the content")

    def process_question(self, question):
        # Perform NLP on the question to identify intent and key entities
        doc = nlp(question)
        intent = None  # Placeholder for intent identification
        entities = [ent.text.lower() for ent in doc.ents]
        return intent, entities

    def find_answer(self, question):
        # Process the content of the website
        website_content = self.content.lower()
    
        # Check if the question is present in the website content
        if question.lower() in website_content:
            # Find the answer by locating the text after the question in the website content
            question_index = website_content.index(question.lower())
            answer_index = question_index + len(question)
            # Extract the answer text
            answer = website_content[answer_index:].split('.')[0].strip()
            return answer
        else:
            return "I couldn't find an answer to that question on this website."

# Instantiate the chatbot
chatbot = ChatBot()

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('chatbot.html')

@app.route('/get', methods=['POST'])
def get_bot_response():
    user_message = request.form['msg']
    chat_log = request.form['chat_log']
    url = request.form['url']

    chatbot.fetch_content(url)  # Fetch the content for the given URL
    response = chatbot.find_answer(user_message)  # Pass only the question here

    return jsonify({'msg': response, 'chat_log': chat_log + "<p class='user-msg'>" + user_message + "</p>" + response})

if __name__ == '__main__':
    app.run(debug=True)
