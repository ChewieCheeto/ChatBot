import random
from flask import Flask, request, jsonify, render_template
from flask import Flask, render_template
from bs4 import BeautifulSoup
import requests
import spacy

nlp = spacy.load("en_core_web_sm")

class ChatBot:
    def __init__(self, url):
        self.url = url
        self.content = self.fetch_content()
        self.doc = self.process_content()

    def fetch_content(self):
        response = requests.get(self.url)
        if response.status_code == 200:
            return response.text
        else:
            raise Exception("Failed to fetch the content")

    def process_content(self):
        soup = BeautifulSoup(self.content, "html.parser")
        text = soup.get_text()
        doc = nlp(text)
        return doc

    def extract_answers(self, question):
        question_doc = nlp(question)
        matches = []
        for chunk in self.doc.noun_chunks:
            if chunk.text.lower() in question_doc.text.lower() or question_doc.text.lower() in chunk.text.lower():
                matches.append((chunk.text, chunk.root.dep_, chunk.root.head.text))

        filtered_matches = []
        for match in matches:
            if match[1] == "pobj" and match[2] == "in":
                filtered_matches.append(match)

        if not filtered_matches:
            return "I couldn't find an answer to that question."

        answer = ""
        for match in filtered_matches:
            answer += match[0] + " "

        return answer

app = Flask(__name__)

@app.route('/')
def index():
    #return '<h1>Hello, World!</h1>'
    return render_template('chatbot.html')

@app.route('/get', methods=['POST'])
def get_bot_response():
    user_message = request.form['msg']
    chat_log = request.form['chat_log']
    url = request.form['url']

    def process_message(user_message, chat_log, url):
        if user_message.lower() == 'hello':
            response = 'Hello! How can I help you?'
        elif user_message.lower() == 'bye':
            response = 'Goodbye!'
        else:
            chatbot = ChatBot(url)
            response = chatbot.extract_answers(user_message)
            if not response:
                response = "I'm sorry, I didn't understand your message."

        return response

    response = process_message(user_message, chat_log, url)

    chat_log += '<div class="user-message">' + user_message + '</div>'
    chat_log += '<div class="bot-message">' + response + '</div>'

    return jsonify({'status': 'success', 'response': chat_log})

if __name__ == '__main__':
    app.run(debug=True, port=4000)
